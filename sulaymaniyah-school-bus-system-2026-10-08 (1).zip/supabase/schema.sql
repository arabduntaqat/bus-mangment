-- =========================================================================
-- Sulaymaniyah School Bus Pass Management System — Supabase PostgreSQL Schema
-- City: Sulaymaniyah, Kurdistan Region, Iraq
-- Currency: Iraqi Dinar (IQD / د.ع)
-- Language: Kurdish Sorani (ckb / کوردی سۆرانی) & English
-- =========================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. SCHOOLS DIRECTORY TABLE
CREATE TABLE IF NOT EXISTS public.schools (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_ku TEXT NOT NULL,
    name_en TEXT NOT NULL,
    neighborhood_ku TEXT NOT NULL,
    neighborhood_en TEXT NOT NULL,
    school_type TEXT NOT NULL DEFAULT 'public', -- 'public', 'private', 'model'
    logo_url TEXT,
    is_verified BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. STUDENTS ROSTER & BUS PASS TABLE
CREATE TABLE IF NOT EXISTS public.students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id_number TEXT UNIQUE NOT NULL, -- e.g. 'SLY-2026-101'
    full_name TEXT NOT NULL,
    school_name TEXT NOT NULL,
    school_logo TEXT,
    phone_number TEXT,
    bus_number TEXT NOT NULL,
    bus_pass_number TEXT UNIQUE NOT NULL, -- e.g. 'PASS-SLY-2026-8841'
    route_name TEXT NOT NULL,
    neighborhood TEXT NOT NULL, -- Sulaymaniyah zone (e.g. سەرچنار, بەختیاری, ڕاپەڕین)
    boarding_point TEXT NOT NULL,
    drop_off_point TEXT NOT NULL,
    monthly_pass_price NUMERIC NOT NULL DEFAULT 50000, -- IQD
    pass_start_date DATE NOT NULL,
    pass_expiry_date DATE NOT NULL,
    pass_status TEXT NOT NULL DEFAULT 'active', -- 'active', 'deactivated', 'expired', 'lost', 'cancelled'
    parent_name TEXT,
    grade_level TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. PAYMENT RECEIPTS AUDIT TABLE
CREATE TABLE IF NOT EXISTS public.payment_receipts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    receipt_number TEXT UNIQUE NOT NULL, -- e.g. 'REC-202610-8841'
    student_id UUID REFERENCES public.students(id) ON DELETE CASCADE,
    student_full_name TEXT NOT NULL,
    student_id_number TEXT NOT NULL,
    bus_pass_number TEXT NOT NULL,
    school_name TEXT NOT NULL,
    school_logo TEXT,
    bus_number TEXT NOT NULL,
    route_name TEXT,
    amount_paid NUMERIC NOT NULL, -- IQD
    payment_status TEXT NOT NULL DEFAULT 'PAID',
    exact_timestamp TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    payment_date_formatted TEXT NOT NULL,
    payment_day TEXT NOT NULL,
    payment_month TEXT NOT NULL,
    payment_year INTEGER NOT NULL,
    payment_time TEXT NOT NULL,
    billing_month_year TEXT NOT NULL,
    billing_month INTEGER NOT NULL,
    billing_year INTEGER NOT NULL,
    next_payment_due_date DATE NOT NULL,
    next_billing_month_year TEXT NOT NULL,
    confirmed_by TEXT NOT NULL,
    payment_method TEXT NOT NULL DEFAULT 'Cash',
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. SYSTEM SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.system_settings (
    id INTEGER PRIMARY KEY DEFAULT 1,
    is_configured BOOLEAN NOT NULL DEFAULT true,
    website_name TEXT NOT NULL DEFAULT 'سیستەمی پاسی سلێمانی',
    school_name TEXT NOT NULL DEFAULT '',
    school_logo TEXT,
    admin_name TEXT NOT NULL DEFAULT 'بەڕێوەبەری گشتی',
    contact_phone TEXT NOT NULL DEFAULT '',
    school_address TEXT NOT NULL DEFAULT 'سلێمانی، هەرێمی کوردستان',
    city TEXT NOT NULL DEFAULT 'سلێمانی (Sulaymaniyah)',
    buses JSONB NOT NULL DEFAULT '["پاس 1", "پاس 2", "پاس 3"]'::jsonb,
    default_monthly_price NUMERIC NOT NULL DEFAULT 50000,
    currency_symbol TEXT NOT NULL DEFAULT 'د.ع',
    preferred_language TEXT NOT NULL DEFAULT 'ku',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE public.schools ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

-- Allow public read of verified schools
CREATE POLICY "Public schools are viewable by everyone" 
ON public.schools FOR SELECT USING (true);

-- Allow public pass verification (restricted view of status and bus info)
CREATE POLICY "Public can verify student pass validity" 
ON public.students FOR SELECT USING (true);

-- Allow authenticated admins to do all operations
CREATE POLICY "Admins have full access to students" 
ON public.students FOR ALL TO authenticated USING (true);

CREATE POLICY "Admins have full access to receipts" 
ON public.payment_receipts FOR ALL TO authenticated USING (true);

CREATE POLICY "Admins have full access to settings" 
ON public.system_settings FOR ALL TO authenticated USING (true);

-- Indexes for lightning fast lookups
CREATE INDEX IF NOT EXISTS idx_students_pass_number ON public.students(bus_pass_number);
CREATE INDEX IF NOT EXISTS idx_students_id_number ON public.students(student_id_number);
CREATE INDEX IF NOT EXISTS idx_receipts_student_id ON public.payment_receipts(student_id);
CREATE INDEX IF NOT EXISTS idx_receipts_billing_period ON public.payment_receipts(billing_month, billing_year);
